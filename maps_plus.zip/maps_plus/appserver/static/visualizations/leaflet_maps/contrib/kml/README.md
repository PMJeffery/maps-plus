### KML Overlays
Place any KML files in this directory you wish to overlay onto the map. Click 'Format' in the UI, click the 'Overlays' tab and then spcify a comma separated list of KML files to load.

#### Example
file1.kml,file2.kml
